
from setuptools import setup
setup(name="newmypackage",
version="0.2",
description="This is code with deepiha package",
long_description = "This is a very very long description",
author="Deepiha",
packages=['newmypackage'],
install_requires=[])